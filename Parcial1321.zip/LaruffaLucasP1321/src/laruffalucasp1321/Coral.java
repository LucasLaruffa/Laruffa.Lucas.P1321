package laruffalucasp1321;



public class Coral extends Especie{
    
    private double profundidadIdeal;

    public Coral(double profundidadIdeal, String nombre, String ubicacionTanque, TipoAgua tipo) {
        super(nombre, ubicacionTanque, tipo);
        validarProfundidad(profundidadIdeal);
        this.profundidadIdeal = profundidadIdeal;
    }

    @Override
    String respirar() {
        return getNombre() + " RESPIRA A TRAVES DE DIFUSIÓN DIRECTA. ";
    }

    @Override
    String alimentarse() {
        return "COMIENZA A ALIMENTARSE DE FORMA HETEROTROFA. \n";
        
    }

    @Override
    String reproducirse() {
        return "SE REPRODUCE CON OTRO CORAL.";
        
    }
    
    
    private void validarProfundidad(double deep){
        if(deep <=0){
            throw new IllegalArgumentException("PROFUNDIDAD DE " + getNombre()+ " INVALIDA.");
        }
    }
    

}
