package laruffalucasp1321;

import java.util.ArrayList;

public class Acuario implements Biologico {

    private String nombre;
    private ArrayList<Especie> especies;

    public Acuario(String nombre) {
        Utils.validarString(nombre);
        this.nombre = nombre;
        especies = new ArrayList<>();
    }

    public void agregarEspecie(Especie e) throws EspecieExistenteException {
        chequearEspecie(e);
        if (especies.contains(e)) {
            throw new EspecieExistenteException();
        }
        especies.add(e);
    }

    public String mostrarEspecies() {
        StringBuilder sb = new StringBuilder();
        sb.append("--ESPECIES DEL ACUARIO--\n");
        for (Especie es : especies) {
            sb.append(es.toString());
        }
        return sb.toString();
    }

    public String moverEspecies() {
        StringBuilder sb = new StringBuilder();
        sb.append("--ESPECIES COMIENZAN A MOVERSE--\n");
        sb.append("RECORDEMOS QUE LOS CORALES NO SE MUEVEN\n");
        for (Especie es : especies) {
            if (es instanceof Movible mv) {
                sb.append(mv.moverEspecie());
            }
        }
        return sb.toString();
    }

    @Override
    public String realizarFuncionesBiologicas() {
        StringBuilder sb = new StringBuilder();
        sb.append("--ESPECIES SIMPLEMENTE VIVEN--\n");
        for(Especie e : especies){
            sb.append(e.realizarFuncionesBiologicas());
        }
        return sb.toString();
        
    }
    
    public String filtrarPorTipoAgua(TipoAgua tipo){
        StringBuilder sb = new StringBuilder();
        sb.append("--ESPECIES QUE VIVEN EN ").append(tipo).append("\n");
        for (Especie e : especies){
            if(e.getTipoAgua().equals(tipo)){
                sb.append(e.toString());
            }
        }
        return sb.toString();
    }

    private void chequearEspecie(Especie esp) {
        if (esp == null) {
            throw new IllegalArgumentException("UNA ESPECIE MAL CARGADA INTENTÓ AGREGARSE AL ACUARIO.");
        }
    }

}
