package laruffalucasp1321;


public interface Biologico {
    String realizarFuncionesBiologicas();
}
