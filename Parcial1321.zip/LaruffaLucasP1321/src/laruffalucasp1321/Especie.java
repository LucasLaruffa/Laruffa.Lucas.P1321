package laruffalucasp1321;

import java.util.Objects;

public abstract class Especie implements Biologico {

    private String nombre;
    private String ubicacionTanque;
    private TipoAgua tipoAgua;

    public Especie(String nombre, String ubicacionTanque, TipoAgua tipo) {
        Utils.validarString(nombre);
        Utils.validarString(ubicacionTanque);
        this.nombre = nombre;
        this.ubicacionTanque = ubicacionTanque;
        tipoAgua = tipo;
    }

    abstract String respirar();

    abstract String alimentarse();

    abstract String reproducirse();

    @Override
    public String realizarFuncionesBiologicas() {
        StringBuilder sb = new StringBuilder();

        sb.append(respirar()).append(alimentarse());

        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(nombre).append(" UBICADO EN EL ").append(ubicacionTanque).append(". ");

        return sb.toString();
    }

    @Override
    public int hashCode() {

        return Objects.hash(nombre, ubicacionTanque);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof Especie e)) {
            throw new IllegalArgumentException("LA ESPECIE COMPARADA CON" + nombre + ", FUE MAL INGRESADA");
        }
        return this.nombre.equals(e.nombre) && this.ubicacionTanque.equals(e.ubicacionTanque);
    }

    public TipoAgua getTipoAgua() {
        return tipoAgua;
    }

    public String getNombre() {
        return nombre;
    }
    
    

}
