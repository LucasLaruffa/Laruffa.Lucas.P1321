package laruffalucasp1321;



public class Molusco extends EspecieMovible {
    private TipoConcha tipoConcha;

    public Molusco(String nombre, String ubicacionTanque, TipoAgua tipo, TipoConcha tipoConcha) {
        super(nombre, ubicacionTanque, tipo);
        this.tipoConcha = tipoConcha;
    }

    @Override
    String respirar() {
        return getNombre() + " RESPIRA A TRAVES DE SU CTENIDIO. ";
    }

    @Override
    String alimentarse() {
        return "AHORA COMIENZA A ALIMENTARSE A TRAVÉS DE SU RADULA. \n";
    }

    @Override
    String reproducirse() {
        return "MIREN! JUNTO A SU PAR COMENZARON A LIBERAR SUS GAMETOS\n";
    }

    @Override
    public String moverEspecie() {
        return getNombre() + " COMIENZA A MOVERSE CON SU PIE MUSCULAR\n";
    }
    
    
    
    
}
