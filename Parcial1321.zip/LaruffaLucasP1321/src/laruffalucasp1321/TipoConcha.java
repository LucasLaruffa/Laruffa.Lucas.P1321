package laruffalucasp1321;

public enum TipoConcha {
    ESPIRALADA,
    UNIVALVA,
    BIVALVA
}
