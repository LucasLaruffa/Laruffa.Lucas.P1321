package laruffalucasp1321;



public abstract class EspecieMovible extends Especie implements Movible {

    public EspecieMovible(String nombre, String ubicacionTanque, TipoAgua tipo) {
        super(nombre, ubicacionTanque, tipo);
    }
    
    

}
