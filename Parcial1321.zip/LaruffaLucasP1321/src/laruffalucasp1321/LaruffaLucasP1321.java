
package laruffalucasp1321;

public class LaruffaLucasP1321 {

    public static void main(String[] args) {
        realizarParcial();
    }
    
    private static void realizarParcial(){
        try{
            Acuario a1 = new Acuario("MUNDO MARINO");
            Pez p1 = new Pez("PEZ PAYASO", "T1", TipoAgua.AGUA_SALADA, 10);
            Pez p2 = new Pez("PEZ PAYASO", "T1", TipoAgua.AGUA_SALADA, 8);
            Molusco m1 = new Molusco("MEJILLON AZUL", "T2", TipoAgua.AGUA_SALADA, TipoConcha.BIVALVA);
            Coral c1 = new Coral(27, "CORAL CEREBRO", "T3", TipoAgua.AGUA_DULCE);
            

            a1.agregarEspecie(p1);
//            a1.agregarEspecie(p2); [ESCENARIO 1] DESCOMENTAR PARA TIRAR EXCEPCION
            a1.agregarEspecie(m1);
            a1.agregarEspecie(c1);

            System.out.println("---------------");
            //ESCENARIO 2
            System.out.println(a1.mostrarEspecies());
            System.out.println("---------------");
            //ESCENARIO 3
            System.out.println(a1.moverEspecies());
            System.out.println("---------------");
            //ESCENARIO 4
            System.out.println(a1.realizarFuncionesBiologicas());
            //ESCENARIO 5
            System.out.println(a1.filtrarPorTipoAgua(TipoAgua.AGUA_DULCE));
            
        }
        catch(EspecieExistenteException ee){
            System.out.println(ee.getMessage());
        }
        catch(IllegalArgumentException ex){
            System.out.println(ex.getMessage());
        }
    }
    
}
