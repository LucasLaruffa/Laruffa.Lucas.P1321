package laruffalucasp1321;



public class Pez extends EspecieMovible {
    
    private double longitudMax;

    public Pez(String nombre, String ubicacionTanque, TipoAgua tipo,double longitudMax) {
        super(nombre, ubicacionTanque, tipo);
        validarLongitud(longitudMax);
        this.longitudMax = longitudMax;
    }

    @Override
    String respirar() {
        return getNombre() + " ABRE Y CIERRA SUS BRANQUIAS. ";
    }

    @Override
    String alimentarse() {
        return "LUEGO COMIENZA A ALIMENTARSE. \n";
    }

    @Override
    String reproducirse() {
        return "WOW! ENCONTRÓ OTRO PAR Y COMENZARON A APAREARSE!.";
    }

    @Override
    public String moverEspecie() {
        return getNombre() + " NADA UTILIZANDO SUS ALETAS\n";
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString()).append("POSEE UNA LONGITUD DE ").append(longitudMax).append("\n");

        return sb.toString();
    }
    
    
    
    private void validarLongitud(double length){
        if(length <= 0){
            throw new IllegalArgumentException("LONGITUD DE "+ getNombre() +" INVALIDA.");
        }
    }
    
    

}
