package laruffalucasp1321;

public enum TipoAgua {
    AGUA_SALADA,
    AGUA_DULCE
}
