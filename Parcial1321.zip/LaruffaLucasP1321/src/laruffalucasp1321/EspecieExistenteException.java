package laruffalucasp1321;



public class EspecieExistenteException extends Exception {

    private static final String MENSAJE = "LA ESPECIE YA EXISTE EN EL ACUARIO";
    public EspecieExistenteException() {
        this(MENSAJE);
    }

    public EspecieExistenteException(String msj) {
        super(msj);
    }

    
}
