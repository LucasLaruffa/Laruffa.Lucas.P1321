package laruffalucasp1321;



public class Utils {
    
    public static void validarString(String cadena){
        if(cadena.isBlank() || cadena.isEmpty()){
            throw new IllegalArgumentException("DATOS CARGADOS INVALIDOS.");
        }
    }
}
