package laruffalucasp1321;


public interface Movible extends Biologico{
    String moverEspecie();
}
